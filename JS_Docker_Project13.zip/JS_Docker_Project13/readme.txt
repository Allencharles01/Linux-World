Task 13: Setup Apache Server inside Docker

## ✅ Objective
Install and configure the Apache HTTP Server inside a Docker container to serve a simple HTML page.

---

## 📁 Folder Structure

JS_Docker_Project13/
├── Dockerfile  
├── index.html  
└── readme.txt  

---

## 🐳 Dockerfile

```Dockerfile
FROM ubuntu:22.04

RUN apt-get update && \
    apt-get install -y apache2 && \
    apt-get clean

COPY index.html /var/www/html/index.html

EXPOSE 80

CMD ["apachectl", "-D", "FOREGROUND"]
````

---

## 🌐 Sample HTML (`index.html`)

```html
<!DOCTYPE html>
<html>
<head>
  <title>Apache Docker</title>
</head>
<body>
  <h1>Hello from Apache running inside Docker! 🚀</h1>
</body>
</html>
```

---

## 🔨 Build the Image

```bash
docker build -t apache-docker .
```

---

## ▶️ Run the Container

```bash
docker run -d -p 8080:80 apache-docker
```

Then open your browser and go to:

```
http://localhost:8080
```

You should see your custom HTML page 🎉

---

## ✅ Done!
