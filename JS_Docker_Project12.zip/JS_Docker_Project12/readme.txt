Task 12: Play VLC Inside Docker (GUI via X11)

## 📌 Objective
Run the VLC Media Player inside a Docker container and display the GUI using X11 on a Windows host.

---

## 🗂 Folder Structure

JS_Docker_Project12/
├── Dockerfile
└── readme.txt

---

## 🐳 Dockerfile Summary

- Base Image: Ubuntu 22.04
- Installs: VLC + X11 packages
- GUI Enabled via X11 socket mount
- Optional: You can mount a local video file to play

---

## 🔨 Build the Docker Image

```bash
docker build -t vlc-docker .
````

---

## ▶️ Run the Container with X11 GUI

Replace `192.168.0.201` with your IP address (check using `ipconfig` on Windows):

```bash
docker run --rm ^
  -e DISPLAY=192.168.0.201:0 ^
  -v /tmp/.X11-unix:/tmp/.X11-unix ^
  vlc-docker
```

> VLC GUI should launch via your X11 server (e.g., VcXsrv).

---

## 🎥 Optional: Play a Specific Video

```bash
docker run --rm ^
  -e DISPLAY=192.168.0.201:0 ^
  -v /tmp/.X11-unix:/tmp/.X11-unix ^
  -v %cd%/sample.mp4:/app/sample.mp4 ^
  vlc-docker sample.mp4
```

Ensure `sample.mp4` exists in the same directory.

---

## ✅ Notes

* Run X11 server (VcXsrv) before launching the container
* Grant access to Docker via `xhost +`
* Adjust path syntax for PowerShell if needed
