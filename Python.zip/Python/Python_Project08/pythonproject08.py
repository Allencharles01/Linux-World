#Send a WhatsApp Message: Use Python to send a WhatsApp message

import pywhatkit
pywhatkit.sendwhatmsg("+918125229368", "Hello from Python!", 12, 23)