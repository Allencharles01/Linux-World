Project: Post on LinkedIn using Python + LinkedIn API

This Python script allows you to post a message directly to your LinkedIn feed using the official LinkedIn API and OAuth 2.0 access.
It’s a great way to automate updates, achievements, or announcements from your apps or personal projects.



-> Features

* Publish text posts to your LinkedIn profile using Python
* Uses LinkedIn API v2 with OAuth 2.0
* Customize your post message and visibility
* Perfect for automation and social media integration



-> How to Use

1. *Clone this repository*

   git clone [https://github.com/your-username/python-linkedin-poster.git](https://github.com/your-username/python-linkedin-poster.git)
   cd python-linkedin-poster

2. *Install Python (if not installed)*

   Download and install Python from: [https://www.python.org/downloads/](https://www.python.org/downloads/)

3. *Install the required library*

   pip install requests

4. *Open lw\_project04.py and update your LinkedIn credentials and post content*

   Replace:

   * `'YOUR_ACCESS_TOKEN'` with your **LinkedIn OAuth access token**
   * `'urn:li:person:YOUR_PERSON_URN'` with your **LinkedIn user URN**
   * Update the `"text"` field in `post_data` to customize your message



-> How to Get Your LinkedIn API Access

*Step 1: Create a LinkedIn App*

* Go to [https://www.linkedin.com/developers/](https://www.linkedin.com/developers/)
* Create a new app
* Under “Products,” add **`w_member_social`** permission
* Note down your **Client ID** and **Client Secret**

*Step 2: Generate an Access Token*

* Use OAuth 2.0 flow OR manually generate a developer access token
  (found under your app > Auth tab > OAuth 2.0 Tools)
* Make sure the token includes `w_member_social` scope

*Step 3: Get Your LinkedIn Person URN*

* Use the following API call to get your URN:

  ```
  GET https://api.linkedin.com/v2/me
  ```
* You'll get a response like: `"id": "abc123..."`
  Your URN will be: `urn:li:person:abc123...`



-> Security Warning

* Never share your access token publicly
* Avoid hardcoding it in public repositories
* Instead, store it securely using:

  * Environment variables (like `os.environ['LINKEDIN_TOKEN']`)
  * A `.env` file with `python-dotenv`



=> Output Example

When run successfully, you should see:

```
✅ Post successfully created on LinkedIn!
```

If something goes wrong:

```
❌ Failed to post: 401 or 403
{"message":"..."}
```


Author:
Made by @Allencharles01
GitHub: https://github.com/Allencharles01