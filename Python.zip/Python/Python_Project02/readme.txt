*Project: *Send SMS Using Python + Fast2SMS API*

This Python script allows you to send SMS messages to Indian mobile numbers using the Fast2SMS API.
It’s a great way to automate OTPs, alerts, or simple messages directly from your Python apps.

-> Features

* Send SMS using Fast2SMS HTTP API
* Quick transactional route (no DLT approval needed)
* Built-in error response display
* Easy to customize message and phone number


-> How to Use

1. *Clone this repository*

   git clone [https://github.com/your-username/python-sms-sender.git](https://github.com/your-username/python-sms-sender.git)
   cd python-sms-sender

2. *Install Python (if not installed)*

   Download and install Python from: [https://www.python.org/downloads/](https://www.python.org/downloads/)

3. *Open lw\_project02.py and update your Fast2SMS credentials*

   Replace:

   * `'ENTER YOUR API KEY'` with your Fast2SMS API key
   * `"0123456789"` with the recipient’s 10-digit Indian mobile number
   * Customize the `"message"` field as needed


-> How to Get Your Fast2SMS API Key

To send SMS, you'll need to create an account and retrieve your API key:

*Step 1: Create a Free Account*

* Visit [https://www.fast2sms.com/](https://www.fast2sms.com/)
* Sign up or log in with your mobile number and email
* Verify your identity using OTP

*Step 2: Get Your API Key*

* After login, go to your Dashboard
* Click on *"Dev API"*
* Copy the *Authorization API Key* shown

*Step 3: Use the API Key in your script*

* Replace this line in the code:
  `'authorization': 'ENTER YOUR API KEY'`
  with:
  `'authorization': 'your_actual_api_key'`


-> Security Warning

* Never share your API Key publicly
* Avoid hardcoding it directly in scripts if uploading to GitHub
* Instead, store it securely using:

  * Environment variables (like `os.environ['FAST2SMS_API_KEY']`)
  * A `.env` file with `python-dotenv`



=> Output Example

When run successfully, you should see a JSON response:

```json
{"return":true,"request_id":"xxxx-xxxx","message":["SMS sent successfully."]}
```


Author:
Made by @Allencharles01
GitHub: https://github.com/Allencharles01