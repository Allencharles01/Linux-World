Project: All-in-One Python Automation Hub (Menu-Driven Tool)

This Python script combines all your automation tasks — like sending emails, SMS, WhatsApp messages, social media posts, and voice calls — into a single, menu-driven terminal program.
Perfect for centralized control, personal productivity tools, or automation demos.


-> Features

* Menu-based user interface
* Execute 8 powerful tasks from a single Python script:

  * Send Email (Gmail SMTP)
  * Send SMS (Fast2SMS API)
  * Make a Phone Call (Twilio Voice API)
  * Post on LinkedIn (LinkedIn API)
  * Post a Tweet (Twitter API with Tweepy)
  * Post on Facebook Page (Facebook Graph API)
  * Post on Instagram (Instagram Graph API)
  * Send WhatsApp Message (via pywhatkit)



-> How to Use

1. *Clone this repository*

   git clone [https://github.com/your-username/python-automation-hub.git](https://github.com/your-username/python-automation-hub.git)
   cd python-automation-hub

2. *Install Python (if not installed)*

   Download Python: [https://www.python.org/downloads/](https://www.python.org/downloads/)

3. *Install the required libraries*

```bash
pip install requests tweepy pywhatkit twilio
```

4. *Open lw\_project09.py and update your credentials*

   Replace placeholder values like:

   * `your_email@gmail.com`, `your_app_password`
   * API keys and tokens for Twilio, Fast2SMS, Twitter, LinkedIn, Facebook, Instagram
   * Target phone numbers, URLs, captions, etc.



-> Menu Options

When you run the script, you’ll see a menu:

```
📍 Python Automation Hub
1. Send Email
2. Send SMS
3. Make a Phone Call
4. Post on LinkedIn
5. Post on Twitter
6. Post on Facebook Page
7. Post on Instagram
8. Send WhatsApp Message
9. Exit
```

Just enter a number and hit **Enter** to run that action.



-> Security Warning

* **Never expose API keys, passwords, or tokens** in public repositories
* Use `.env` files or environment variables for secure credential management
* Consider adding `.gitignore` to exclude sensitive config files



=> Output Example

Depending on the action, you might see:

```
✅ Email sent!
✅ Message sent!
✅ Call initiated!
✅ Tweet posted successfully!
✅ WhatsApp message scheduled!
```

Or error messages if something is misconfigured.

---

Author:
Made by @Allencharles01
GitHub: https://github.com/Allencharles01