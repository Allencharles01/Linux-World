Project: *Send Email with Python using Gmail SMTP*

This Python script lets you send an email via Gmail's SMTP server using a secure App Password. 
It’s a great way to automate simple email alerts or notifications.

-> Features

* Send emails via Gmail using Python’s smtplib
* Secure connection using SMTP\_SSL
* Built-in email formatting using `email.message`
* Easy to customize for subject, body, and recipients


-> How to Use

1. *Clone this repository*

   git clone [https://github.com/your-username/python-email-sender.git](https://github.com/your-username/python-email-sender.git)
   cd python-email-sender

2. *Install Python (if not installed)*

   Download and install Python from: [https://www.python.org/downloads/](https://www.python.org/downloads/)

3. *Open lw_project01.py and update your email credentials*

   Replace:

   * msg['From'] with your Gmail address
   * msg['To'] with the recipient’s email
   * smtp.login() with your Gmail and generated App Password


-> How to Get Your Own Gmail App Password

Since Google blocks "less secure apps," you’ll need to generate an **App Password** using these steps:

*Step 1: Turn on 2-Step Verification*

* Visit [https://myaccount.google.com/security](https://myaccount.google.com/security)
* Under "Signing in to Google", enable 2-Step Verification

*Step 2: Generate an App Password*

* After enabling 2FA, go to [https://myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
* Choose App: "Mail"
* Choose Device: "Other (Custom name)" and name it something like "Python Script"
* Click "Generate"
* Copy the 16-character password Google provides

*Step 3: Use the App Password in your script*

* Replace your Gmail login password with this new App Password in the script
* Example:
  smtp.login('[your\_email@gmail.com](mailto:your_email@gmail.com)', 'your\_app\_password')



-> Security Warning

* Never share your App Password publicly
* Avoid hardcoding it directly in scripts if uploading to GitHub
* Instead, store it securely using:

  * Environment variables (like `os.environ['EMAIL_PASSWORD']`)
  * A `.env` file with `python-dotenv`


=>Output Example

When run successfully, you should see:
"✅ Email sent!"

---

Author:

Made by @Allencharles01 
GitHub: https://github.com/Allencharles01

