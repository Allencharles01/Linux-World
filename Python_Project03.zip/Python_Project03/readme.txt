Project: Make a Phone Call using Python + Twilio API

This Python script allows you to make a voice call to an Indian phone number using the Twilio API.
It's perfect for sending automated calls for alerts, notifications, or demo voice messages.

-> Features

* Make voice calls using Twilio's REST API
* Plays a default or custom message using a TwiML URL
* Supports international calls (including Indian numbers with `+91`)
* Simple to configure and run from a Python script

-> How to Use

1. *Clone this repository*

   git clone [https://github.com/your-username/python-call-maker.git](https://github.com/your-username/python-call-maker.git)
   cd python-call-maker

2. *Install Python (if not installed)*

   Download and install Python from: [https://www.python.org/downloads/](https://www.python.org/downloads/)

3. *Install the required library*

   pip install twilio

4. *Open lw\_project03.py and update your Twilio credentials and phone numbers*

   Replace:

   * `'your_account_sid'` with your Twilio Account SID
   * `'your_auth_token'` with your Twilio Auth Token
   * `from_number` with your Twilio phone number (e.g., `+1415XXXXXXX`)
   * `to_number` with the Indian phone number you want to call (e.g., `+91XXXXXXXXXX`)
   * `url` with your TwiML URL (or use the default)


-> How to Get Your Twilio Credentials

*Step 1: Sign Up on Twilio*

* Visit [https://www.twilio.com/](https://www.twilio.com/)
* Create a free account
* Verify your phone number

*Step 2: Get Your SID, Auth Token, and Number*

* After login, go to the **Console Dashboard**
* Copy your **Account SID** and **Auth Token**
* Get a **Twilio phone number** (available in the same dashboard)

*Step 3: Update your script*

* Open `lw_project03.py`
* Replace the placeholders with your actual Twilio details
* Use the demo voice message URL: `http://demo.twilio.com/docs/voice.xml`
  (or you can create your own voice instructions)


-> Security Warning

* Never share your Account SID or Auth Token publicly
* Avoid hardcoding them directly in scripts if uploading to GitHub
* Instead, store them securely using:

  * Environment variables (like `os.environ['TWILIO_AUTH_TOKEN']`)
  * A `.env` file with `python-dotenv`


=> Output Example**

When the call is placed successfully, you’ll see:

```
📞 Call initiated! SID: CAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

The recipient will receive a phone call and hear a voice message.



Author:
Made by @Allencharles01
GitHub: https://github.com/Allencharles01