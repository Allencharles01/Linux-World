Task 2 : Create a new branch → make changes → merge into `main` → ensure no merge conflicts

---

### 🧰 **Starting Point**

Make sure you're inside your project folder from Task 1:

```bash
cd git-task01
```

---

## 🧪 Step-by-Step Guide

---

### 🌱 Step 1: Create and switch to a new branch `feature1`

**Where:** VS Code Terminal or CMD

```bash
git checkout -b feature1
```

> ✅ This creates the branch and moves you to it

---

### ✏️ Step 2: Make a change in the file

```bash
echo "This is a line added from feature1 branch." >> task.txt
```

You can also open `task.txt` and manually edit it.

---

### ✅ Step 3: Add and commit the change

```bash
git add task.txt
git commit -m "Update task.txt in feature1 branch"
```

---

### 🔁 Step 4: Switch back to the main branch

```bash
git checkout main
```

---

### 🔀 Step 5: Merge `feature1` into `main`

```bash
git merge feature1
```

✅ If there are **no conflicting edits**, it will merge cleanly.

---

### ☁️ Step 6: Push changes to GitHub

```bash
git push
```

> Or if the branch hasn't been pushed before:

```bash
git push origin main
```

---

## 💡 Tip: How to Create Merge Conflicts (for practice)

Edit the **same line** in `task.txt` in both `main` and `feature1`, then try to merge — Git will show a conflict.

---

✅ **Task Complete!** You’ve successfully created a branch, made changes, and merged it.
