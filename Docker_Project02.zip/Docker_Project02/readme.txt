### 📁 `README.txt` – Docker\_Project01 (ubuntu-curl)

---

**🧠 Project Name:** Run `curl` inside a Dockerized Ubuntu container
**🗂️ File:** `Dockerfile`
**📄 Description:**
This project demonstrates how to build a custom Docker image based on Ubuntu that has `curl` pre-installed.

---

### 🛠️ Features:

* Custom image built from `ubuntu:latest`
* Automatically installs `curl` using `apt`
* Opens in interactive terminal (`bash`)
* Useful for testing APIs or networking tools inside isolated containers

---

### 🚀 How to Use:

1. **Clone or create the project directory:**

   ```bash
   mkdir Docker_Project01
   cd Docker_Project01
   ```

2. **Create a `Dockerfile` with the following content:**

   ```Dockerfile
   FROM ubuntu:latest

   RUN apt update && apt install curl -y

   CMD ["bash"]
   ```

3. **Build the Docker image:**

   ```bash
   docker build -t ubuntu-curl .
   ```

4. **Run the image:**

   ```bash
   docker run -it ubuntu-curl
   ```

5. **Test curl (inside the container):**

   ```bash
   curl https://api.github.com
   ```

---

### 📌 Notes:

* The image is tagged as `ubuntu-curl`
* Make sure Docker Desktop is running
* You must have an active internet connection to pull base images and install packages

---

### 👨‍💻 Author:

Created by **Allen Charles**
GitHub: [https://github.com/Allencharles01](https://github.com/Allencharles01)

---

### 📦 Output Example:

```bash
{
  "current_user_url": "https://api.github.com/user",
  ...
}
```

✅ If you see JSON output, curl is working perfectly inside Docker.