Project: Gemini Resume Analyzer using Gradio

---

## 🎯 Objective

Analyze a candidate's resume using Google's Gemini API and get:

1. Match Score (out of 100)
2. Missing Skills or Experience
3. Suggested Project Idea
4. Keywords to Add
5. Job Link Suggestions (LinkedIn, Indeed, Internshala)

---

## 📁 Folder Structure

Main_Project01/
├── resume_analyzer.py
├── requirements.txt
├── readme.txt
└── .env (optional for storing Gemini API key)

---

## 🔧 Installation

1. 🔁 Clone or download the project folder
2. 🐍 Create a virtual environment (optional)

```bash
python -m venv venv
venv\Scripts\activate   # Windows
````

3. 📦 Install required packages

```bash
pip install -r requirements.txt
```

---

## 🔐 Add Your Gemini API Key

In `resume_analyzer.py`, replace:

```python
GEMINI_API_KEY = "INSERT API HERE"
```

Or store it in a `.env` file and load it via `os.getenv("GEMINI_API_KEY")`

---

## 🚀 How to Run

```bash
python resume_analyzer.py
```

This will launch a local Gradio app in your browser.

---

## 🧪 How to Use

1. Select input mode: Paste Text or Upload PDF
2. Enter:

   * 🎯 Role (e.g., Backend Developer)
   * 🏢 Company (e.g., Microsoft)
   * 📍 Location (e.g., Bengaluru)
3. Click "📊 Analyze Resume"
4. View feedback, missing skills, project suggestions, and job links

---

## 🧠 Notes

* Requires a valid **Gemini API key** from Google
* Resume PDF should be text-based (not just scanned image)

---

## ✅ You're All Set!

Gemini-powered resume analysis is just a click away. Tailor your profile with AI insight 🚀
