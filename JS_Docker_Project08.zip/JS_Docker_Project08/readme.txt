Task 8: Run Flask App inside Docker

## ✅ Objective
Create and run a simple Flask web application inside a Docker container.

---

## 📁 Folder Structure

JS_Docker_Project08/
├── app.py  
├── Dockerfile  
├── requirements.txt  
├── readme.txt ← (this file)

---

## 📜 Step-by-Step Guide

### 1. Create the Flask App (`app.py`)
```python
from flask import Flask

app = Flask(__name__)

@app.route('/')
def home():
    return "🎉 Hello from Flask running in Docker!"

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
````

---

### 2. Define Dependencies (`requirements.txt`)

```
flask
```

---

### 3. Create Dockerfile

```Dockerfile
FROM python:3.10-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY app.py .

CMD ["python", "app.py"]
```

---

### 4. Build Docker Image

Open CMD or PowerShell in the folder and run:

```
docker build -t flask-app-js08 .
```

---

### 5. Run Docker Container

```
docker run -p 5000:5000 flask-app-js08
```

Visit in your browser:

```
http://localhost:5000/
```

You should see:
**🎉 Hello from Flask running in Docker!**

---

## 🏁 Done!