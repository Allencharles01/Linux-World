Task 1: Capture a Photo Using JavaScript & Webcam

---

### ✅ **Goal**

Build a small web page that:

* Accesses the webcam
* Displays the live video feed
* Captures a photo when a button is clicked
* Shows the photo using a `<canvas>`

---

### 🧱 **Tools Used**

| Tool                        | Purpose                |
| --------------------------- | ---------------------- |
| HTML5 `<video>`             | Show webcam feed       |
| HTML5 `<canvas>`            | Display captured image |
| JavaScript `getUserMedia()` | Access webcam          |

---

### 🧪 **Steps to Run the Project**

---

#### ✅ Step 1: Create a File

Save the following code as:

```bash
index.html
```

---

#### ✅ Step 2: Paste the Code

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Webcam Photo Capture</title>
  <style>
    video, canvas {
      display: block;
      margin-bottom: 10px;
      max-width: 100%;
    }
  </style>
</head>
<body>
  <h2>📸 Take a Photo</h2>
  <video id="video" autoplay></video>
  <button onclick="capture()">Capture Photo</button>
  <canvas id="canvas"></canvas>

  <script>
    const video = document.getElementById('video');
    const canvas = document.getElementById('canvas');
    const context = canvas.getContext('2d');

    navigator.mediaDevices.getUserMedia({ video: true })
      .then(stream => {
        video.srcObject = stream;
      })
      .catch(err => {
        console.error('Error accessing webcam:', err);
      });

    function capture() {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context.drawImage(video, 0, 0);
    }
  </script>
</body>
</html>
```

---

#### ✅ Step 3: Run the File

* Double-click `index.html` or right-click → **Open in Browser**
* Grant webcam access
* Click **"Capture Photo"** to freeze the current frame

---

### 💡 Optional Ideas

* Add a **Download button** to save the image
* Dockerize it (Task 2?)
* Style the layout with Tailwind or Bootstrap

---

✅ Task Complete! You’ve now captured a webcam photo using just HTML + JavaScript.