Task 1: Create a Git repository, commit a file, and push to GitHub

---

### 🧰 **Requirements**

* Git installed on Windows
* GitHub account
* VS Code Terminal or CMD/PowerShell
* Logged in to GitHub (or access to GitHub token)

---

## 🧪 **Step-by-Step Instructions**

---

### ✅ Step 1: Create a new folder

**Where:** CMD / PowerShell / VS Code Terminal

```bash
mkdir git-task01
cd git-task01
```

---

### ✅ Step 2: Initialize Git in the folder

**Where:** VS Code Terminal / CMD

```bash
git init
```

---

### ✅ Step 3: Add a sample file

**Where:** VS Code Terminal

```bash
echo "This is my first Git task." > task.txt
```

---

### ✅ Step 4: Add the file to Git staging

```bash
git add task.txt
```

---

### ✅ Step 5: Commit with a message

```bash
git commit -m "Initial commit: Add task.txt"
```

---

### ✅ Step 6: Create a new GitHub repository

**Where:**
Go to: [https://github.com](https://github.com)

Click **New Repository**

* Repo name: `git-task01`
* Don't check "Initialize with README"
* Click **Create Repository**

---

### ✅ Step 7: Link your GitHub repo

Replace the link with your GitHub repo’s actual HTTPS URL:

```bash
git remote add origin https://github.com/your-username/git-task01.git
```

---

### ✅ Step 8: Push to GitHub

```bash
git branch -M main
git push -u origin main
```

---

### ✅ Result:

Your `task.txt` file is now committed locally and pushed to your GitHub repo ✅
Visit your repo on GitHub to confirm!
