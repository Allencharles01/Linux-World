def show_menu():
    print("\n===== MENU =====")
    print("1. Greet")
    print("2. Add Numbers")
    print("3. Exit")

def greet():
    name = input("Enter your name: ")
    print(f"Hello, {name}!")

def add_numbers():
    try:
        a = float(input("Enter first number: "))
        b = float(input("Enter second number: "))
        print("Sum:", a + b)
    except ValueError:
        print("Invalid input. Please enter numbers.")

if __name__ == "__main__":
    while True:
        show_menu()
        choice = input("Choose an option: ")
        if choice == '1':
            greet()
        elif choice == '2':
            add_numbers()
        elif choice == '3':
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")
