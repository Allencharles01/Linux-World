Task 9: Run Menu-Based Python Project inside Docker

---

## 🎯 Objective

Create a **menu-driven CLI Python app** and run it inside a Docker container with full terminal input/output support.

---

## 📁 Project Structure

JS_Docker_Project09/
├── menu_app.py  
├── requirements.txt  
├── Dockerfile  
└── readme.txt ← (this file)

---

## 🐍 menu_app.py

```python
def show_menu():
    print("\n===== MENU =====")
    print("1. Greet")
    print("2. Add Numbers")
    print("3. Exit")

def greet():
    name = input("Enter your name: ")
    print(f"Hello, {name}!")

def add_numbers():
    try:
        a = float(input("Enter first number: "))
        b = float(input("Enter second number: "))
        print("Sum:", a + b)
    except ValueError:
        print("Invalid input. Please enter numbers.")

if __name__ == "__main__":
    while True:
        show_menu()
        choice = input("Choose an option: ")
        if choice == '1':
            greet()
        elif choice == '2':
            add_numbers()
        elif choice == '3':
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")
````

---

## 📦 requirements.txt

```
# No external packages needed
```

Leave this file empty if not using any pip modules.

---

## 🐳 Dockerfile

```Dockerfile
FROM python:3.10-slim

WORKDIR /app

COPY . .

CMD ["python", "menu_app.py"]
```

---

## 🚀 How to Build and Run

### 🛠️ Step 1: Build Docker Image

```bash
docker build -t menu-cli-app .
```

---

### ▶️ Step 2: Run the Container with Terminal Support

```bash
docker run -it menu-cli-app
```

> `-it` lets Docker pass input/output between the terminal and your Python script.

---

## ✅ Output Example

```
===== MENU =====
1. Greet
2. Add Numbers
3. Exit
Choose an option:
```

---

## 🏁 Done!
