Task 3: Capture Photo via Webcam and Send It via Email Using EmailJS

---

### 🎯 **Goal**

Build a frontend-only app that:

1. Accesses your webcam
2. Captures a photo
3. Sends it via email as a base64-encoded image using **EmailJS**

---

### 🧰 **Tools Used**

| Tool                   | Purpose                      |
| ---------------------- | ---------------------------- |
| HTML + JavaScript      | UI + logic                   |
| `<video>` + `<canvas>` | Webcam & image capture       |
| EmailJS                | Email delivery from frontend |

---

### 🧪 **Step-by-Step Instructions**

---

### 1️⃣ Create an EmailJS Account

* Go to [https://emailjs.com](https://emailjs.com)
* Create an account and log in
* Link a service (e.g. Gmail)
* Create an **email template**
* Get your:

  * `Public Key`
  * `Service ID`
  * `Template ID`

---

### 2️⃣ Create an `index.html` File

Paste the following code:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Send Captured Photo via Email</title>
  <script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
  <style>
    video, canvas {
      display: block;
      margin: 10px 0;
      max-width: 100%;
    }
  </style>
</head>
<body>
  <h2>📸 Capture & Send Photo</h2>
  
  <video id="video" autoplay></video>
  <button onclick="capture()">Capture</button>
  <canvas id="canvas" style="display:none;"></canvas>

  <form id="photo-form">
    <input type="email" name="to_email" placeholder="Recipient Email" required><br />
    <input type="hidden" name="image_data" id="image_data">
    <button type="submit">Send Photo</button>
  </form>

  <script>
    (function() {
      emailjs.init("YOUR_PUBLIC_KEY");
    })();

    const video = document.getElementById('video');
    const canvas = document.getElementById('canvas');
    const context = canvas.getContext('2d');

    navigator.mediaDevices.getUserMedia({ video: true })
      .then(stream => {
        video.srcObject = stream;
      })
      .catch(err => {
        console.error("Webcam error:", err);
      });

    function capture() {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context.drawImage(video, 0, 0);
      document.getElementById('image_data').value = canvas.toDataURL('image/png');
    }

    document.getElementById('photo-form').addEventListener('submit', function(e) {
      e.preventDefault();
      emailjs.sendForm('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', this)
        .then(() => alert("Photo sent successfully!"))
        .catch(err => alert("Failed to send photo:\n" + JSON.stringify(err)));
    });
  </script>
</body>
</html>
```

---

### 3️⃣ Update Your Email Template in EmailJS

In your EmailJS template’s message field, include:

```html
<img src="{{image_data}}" alt="Captured Photo" />
```

---

### 4️⃣ Replace These in Your Code

| Placeholder        | Replace With                      |
| ------------------ | --------------------------------- |
| `YOUR_PUBLIC_KEY`  | Your EmailJS public key           |
| `YOUR_SERVICE_ID`  | From your connected email service |
| `YOUR_TEMPLATE_ID` | Your EmailJS template ID          |

---

### ✅ 5️⃣ Run and Test

* Open `index.html` in your browser
* Allow camera access
* Capture photo
* Enter your email
* Click **Send Photo**
* Check your inbox 📥

---

### ✅ Task Complete!
