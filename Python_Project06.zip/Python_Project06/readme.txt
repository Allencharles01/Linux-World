Project: Post on Facebook Page using Python + Graph API

This Python script allows you to publish a message to your **Facebook Page** using the Facebook Graph API.
It’s a great tool for automating page updates, announcements, and promotional content using code.


-> Features

* Post text content to a Facebook Page using Python
* Uses Facebook Graph API v12+
* Simple and easy-to-configure POST request
* Ideal for automation, bots, or digital marketing tools


-> How to Use

1. *Clone this repository*

   git clone [https://github.com/your-username/python-facebook-poster.git](https://github.com/your-username/python-facebook-poster.git)
   cd python-facebook-poster

2. *Install Python (if not installed)*

   Download and install Python from: [https://www.python.org/downloads/](https://www.python.org/downloads/)

3. *Install the required library*

   pip install requests

4. *Open lw\_project06.py and update the following variables*

   Replace:

   * `'YOUR_PAGE_ACCESS_TOKEN'` with your long-lived **Page Access Token**
   * `'YOUR_PAGE_ID'` with your **Facebook Page ID**
   * Update the `message` variable to post your own content



-> How to Get Your Facebook Page Access Token

*Step 1: Create a Facebook App*

* Go to [https://developers.facebook.com/](https://developers.facebook.com/)
* Create an app (choose **Business** as the app type)
* Go to the app dashboard → Settings → Basic → Note down **App ID** and **App Secret**

*Step 2: Get Access Token with Required Permissions*

* Use [Graph API Explorer](https://developers.facebook.com/tools/explorer/)
* Generate a **User Access Token** with scopes:

  * `pages_manage_posts`
  * `pages_read_engagement`

*Step 3: Get Your Page Access Token*

* Use the endpoint:

  ```
  GET /me/accounts
  ```
* Find your **Page ID** and corresponding **access\_token**

*Step 4: Exchange for Long-Lived Token (Optional but recommended)*

* Use the following URL to exchange:

  ```
  https://graph.facebook.com/oauth/access_token?
  grant_type=fb_exchange_token&
  client_id=YOUR_APP_ID&
  client_secret=YOUR_APP_SECRET&
  fb_exchange_token=SHORT_LIVED_TOKEN
  ```


-> Security Warning

* Never share your access token publicly
* Avoid hardcoding it in public repositories
* Instead, store it securely using:

  * Environment variables (like `os.environ['FB_PAGE_TOKEN']`)
  * A `.env` file with `python-dotenv`



=> Output Example

When run successfully, you should see:

```
✅ Post successfully published to Facebook Page!
```

If it fails:

```
❌ Failed to post: 400 or 403
{ "error": { "message": "...", "type": "...", "code": ... } }
```

---

Author:
Made by @Allencharles01
GitHub: https://github.com/Allencharles01