**🧪 Task 4: Run `systemctl` inside a Docker Container**

---

#### ✅ Objective:

Explore how to run the `systemctl` command inside a Docker container by simulating a `systemd`-enabled Linux environment.

---

#### 🧰 Tools Used:

* **Docker Desktop** on Windows
* **Image used**: `jrei/systemd-centos:latest` (preconfigured with systemd)
* **VS Code Terminal (PowerShell)**

---

#### 🔧 Final Working Command:

```powershell
docker run --privileged --name sysd-ready `
  --tmpfs /run `
  --tmpfs /run/lock `
  -v /sys/fs/cgroup:/sys/fs/cgroup:ro `
  -e container=docker `
  -d jrei/systemd-centos:latest /usr/sbin/init
```

> This starts a privileged container using a CentOS image that supports `systemd`.

---

#### 🚀 Access Container:

```powershell
docker exec -it sysd-ready bash
```

Inside the container:

```bash
# Try systemctl
systemctl

# If D-Bus error shows up:
mkdir -p /run/dbus && dbus-daemon --system
```

---

#### ⚠️ Known Limitation:

Even after setup, `systemctl` may still show limited functionality due to Docker’s architecture. Full `systemd` behavior usually requires:

* Running Docker on Linux with special runtimes
* Using VMs or tools like `systemd-nspawn` or **Sysbox**

---

#### 📘 Summary:

This project demonstrates the complexity of running `systemd` inside a Docker container. We used the best available method via a prebuilt image and privileged flags. Perfect for learning and experimentation.
