Project: Post on Twitter (X) using Python + Twitter API

This Python script allows you to post a tweet directly to your Twitter (X) profile using the official Twitter API and Tweepy.
It’s a simple and effective way to automate social media updates and announcements from your apps.


-> Features

* Post text tweets using Python
* Uses the official Twitter API via Tweepy
* Authenticates with OAuth 1.0a (user access)
* Simple setup and easy customization


-> How to Use

1. *Clone this repository*

   git clone [https://github.com/your-username/python-twitter-poster.git](https://github.com/your-username/python-twitter-poster.git)
   cd python-twitter-poster

2. *Install Python (if not installed)*

   Download and install Python from: [https://www.python.org/downloads/](https://www.python.org/downloads/)

3. *Install the required library*

   pip install tweepy

4. *Open lw\_project05.py and update your Twitter credentials and tweet content*

   Replace:

   * `'YOUR_API_KEY'` with your Twitter API Key
   * `'YOUR_API_SECRET'` with your API Secret
   * `'YOUR_ACCESS_TOKEN'` with your Access Token
   * `'YOUR_ACCESS_TOKEN_SECRET'` with your Access Token Secret
   * Update the `tweet` variable with your desired message



-> How to Get Twitter API Credentials

*Step 1: Apply for Developer Access*

* Go to [https://developer.twitter.com/](https://developer.twitter.com/)
* Sign in with your Twitter account and apply for a Developer account

*Step 2: Create a Project and App*

* Once approved, go to your Developer Dashboard
* Create a **Project** and then an **App**

*Step 3: Get API Keys and Tokens*

* Navigate to the **Keys and Tokens** section
* Copy your:

  * API Key & API Key Secret
  * Access Token & Access Token Secret
* Ensure your app has **Read and Write** permissions enabled

*Step 4: Add Credentials to Your Script*

* Open `lw_project05.py` and replace the placeholder values with your real credentials



-> Security Warning

* Never share your API credentials publicly
* Avoid hardcoding them directly in public repositories
* Instead, store them securely using:

  * Environment variables (like `os.environ['TWITTER_API_KEY']`)
  * A `.env` file with `python-dotenv`



=> Output Example

When run successfully, you should see:

```
✅ Tweet posted successfully!
```

If something fails:

```
❌ Failed to post tweet: [error details]
```

---


Author:
Made by @Allencharles01
GitHub: https://github.com/Allencharles01

