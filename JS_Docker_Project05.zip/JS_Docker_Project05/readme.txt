Task 5: Send WhatsApp Message via JavaScript (No API)

---

### 🎯 **Goal**

Build a simple HTML+JS app that opens WhatsApp Web or the WhatsApp app with a **pre-filled message** to a given phone number using the WhatsApp URL scheme.

---

### 🧱 **Tools Used**

| Tool         | Purpose                      |
| ------------ | ---------------------------- |
| HTML         | Input form and button        |
| JavaScript   | Build URL and open WhatsApp  |
| WhatsApp Web | To send the message manually |

---

### 🧪 **Steps to Complete the Task**

---

### 1️⃣ Create a File Named `index.html`

Paste this code:

```html
<!DOCTYPE html>
<html>
<head>
  <title>Send WhatsApp Message</title>
</head>
<body>
  <h2>💬 Send WhatsApp Message</h2>

  <input type="text" id="phone" placeholder="Phone number (with country code)" /><br><br>
  <textarea id="message" placeholder="Your message here..."></textarea><br><br>
  <button onclick="sendWhatsApp()">Send Message</button>

  <script>
    function sendWhatsApp() {
      const phone = document.getElementById("phone").value;
      const message = encodeURIComponent(document.getElementById("message").value);

      if (phone && message) {
        const url = `https://wa.me/${phone}?text=${message}`;
        window.open(url, '_blank');
      } else {
        alert("Please enter both phone number and message.");
      }
    }
  </script>
</body>
</html>
```

---

### 2️⃣ Run the App

* Open `index.html` in your browser
* Enter:

  * Phone number (e.g. `919876543210` — no `+`)
  * Message (e.g. `Hey Allen, this is a test!`)
* Click **Send Message**
* WhatsApp Web (or app) will open with the message pre-filled

---

### 🧠 Notes

* You must **manually click "Send"** in WhatsApp.
* The phone number must have **WhatsApp installed**.
* This works on:

  * WhatsApp Web
  * Desktop App
  * Mobile Browser (redirects to app)

---

✅ **Task Complete!**