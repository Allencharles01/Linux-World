Project: Post on Instagram using Python + Instagram Graph API

This Python script allows you to post an image with a caption to an *Instagram Business or Creator Account* using the official Instagram Graph API.
It’s a great way to automate content publishing directly from your Python apps.


-> Features

* Post an image to Instagram using Python
* Uses Facebook’s Instagram Graph API (v18.0)
* Supports captions and public image URLs
* Ideal for business/creator automation workflows


-> How to Use

1. *Clone this repository*

   git clone [https://github.com/your-username/python-instagram-poster.git](https://github.com/your-username/python-instagram-poster.git)
   cd python-instagram-poster

2. *Install Python (if not installed)*

   Download and install Python from: [https://www.python.org/downloads/](https://www.python.org/downloads/)

3. *Install the required library*

   pip install requests

4. *Open lw\_project07.py and update the following values:*

   * `access_token` → Your **long-lived user access token**
   * `instagram_account_id` → Your **Instagram Business Account ID**
   * `image_url` → A **publicly accessible** image link
   * `caption` → Your post's message content

5. *Run the script to publish the post*



-> How to Get Your Instagram Access Token & Account ID

*Step 1: Set Up Your Instagram Business or Creator Account*

* Switch your Instagram account to a **Business or Creator account**
* Link it to a **Facebook Page**

*Step 2: Create a Facebook App*

* Go to [https://developers.facebook.com/](https://developers.facebook.com/)
* Create an app with “For Business” type
* Add **Instagram Graph API** and **Facebook Pages API**

*Step 3: Get Access Token*

* Use the **Graph API Explorer** or OAuth flow to generate a token with scopes:

  * `instagram_basic`
  * `pages_read_engagement`
  * `instagram_content_publish`
* Convert to a **long-lived access token**

*Step 4: Get Your Instagram Business Account ID*

* Use the Facebook Page ID to get the connected Instagram account:

  ```
  GET /{page_id}?fields=instagram_business_account
  ```



-> Security Warning

* Never share your access token publicly
* Avoid hardcoding it in public repositories
* Instead, store it securely using:

  * Environment variables (like `os.environ['IG_TOKEN']`)
  * A `.env` file with `python-dotenv`



=> Output Example

When run successfully, you should see:

```
🖼️ Media container created. ID: xxxxxxxxxx
✅ Post published successfully! Post ID: xxxxxxxxxx
```

If something fails:

```
❌ Failed to publish: { "error": { "message": "...", "type": "...", "code": ... } }
```

Author:
Made by @Allencharles01
GitHub: https://github.com/Allencharles01