Task 10: Run Docker Inside Docker (DIND)

---

## 🎯 Objective

Set up and test a Docker container that can run other Docker containers — known as **Docker-in-Docker (DIND)**.  
Used in CI/CD systems, DevOps sandboxes, and advanced container testing.

---

## 📁 Environment Requirements

- Docker Desktop ✅ (running)
- No external files needed — just Docker CLI

---

## 🐳 Step-by-Step Instructions

---

### 1️⃣ Pull and Run the DIND Container

Run this in CMD / PowerShell / VS Code terminal:

```

docker run --privileged --name dind-test -d docker\:dind

```

> ⚠️ `--privileged` is essential. It gives the container permission to manage Docker inside.

---

### 2️⃣ Access the Container

```

docker exec -it dind-test sh

```

Now you're inside the inner container shell: `/ #`

---

### 3️⃣ Check Docker Inside Docker

Run:

```

docker version
docker info

```

✅ You should see both client and server info (Docker daemon is active).

---

### 4️⃣ Run a Docker Container Inside DIND

Test by running:

```

docker run hello-world

```

Expected output: Docker pulls and runs a tiny container that prints "Hello from Docker!"

---

### 🔁 Optional Clean-Up

To stop and remove the DIND container:

```

docker stop dind-test
docker rm dind-test

```

---

## ✅ Output Example

```

Hello from Docker!
This message shows that your installation appears to be working correctly.

```

---

## 🏁 Done!
