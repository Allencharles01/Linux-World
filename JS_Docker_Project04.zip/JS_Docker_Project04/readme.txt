Task 4: Record a Video in Browser and Email It Using EmailJS

---

### 🎯 **Goal**

Use the **MediaRecorder API** to:

1. Access webcam and mic
2. Record a short video
3. Convert it to base64
4. Send it via **EmailJS** through a form

---

### 🧱 **Tools Used**

| Tool              | Purpose                                     |
| ----------------- | ------------------------------------------- |
| HTML5 `<video>`   | Live preview                                |
| MediaRecorder API | Record webcam & mic                         |
| JavaScript        | Encode and send form                        |
| EmailJS           | Send base64 video via email (frontend only) |

---

### 🧪 **Steps to Complete Task**

---

### 1️⃣ EmailJS Setup

* Go to: [https://emailjs.com](https://emailjs.com)
* Sign up and log in
* Link an email service (like Gmail)
* Create a new **email template**
* Get these from dashboard:

  * `Public Key`
  * `Service ID`
  * `Template ID`

---

### 2️⃣ Create `index.html`

Paste this code:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Record & Send Video</title>
  <script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
</head>
<body>
  <h2>🎥 Record & Email a Video</h2>

  <video id="preview" autoplay></video>
  <br>
  <button onclick="startRecording()">Start Recording</button>
  <button onclick="stopRecording()">Stop & Send</button>

  <form id="video-form" style="display:none;">
    <input type="email" name="to_email" placeholder="Recipient Email" required><br>
    <input type="hidden" name="video_data" id="video_data">
    <button type="submit">Send Video</button>
  </form>

  <script>
    emailjs.init("YOUR_PUBLIC_KEY");

    const video = document.getElementById("preview");
    const videoForm = document.getElementById("video-form");
    const videoData = document.getElementById("video_data");

    let mediaRecorder;
    let recordedChunks = [];

    navigator.mediaDevices.getUserMedia({ video: true, audio: true })
      .then(stream => {
        video.srcObject = stream;
        mediaRecorder = new MediaRecorder(stream);

        mediaRecorder.ondataavailable = function(e) {
          if (e.data.size > 0) recordedChunks.push(e.data);
        };

        mediaRecorder.onstop = function() {
          const blob = new Blob(recordedChunks, { type: "video/webm" });
          const reader = new FileReader();
          reader.onloadend = function() {
            videoData.value = reader.result;
            videoForm.style.display = "block";
          };
          reader.readAsDataURL(blob);
        };
      })
      .catch(err => {
        alert("Error accessing media devices.");
        console.error(err);
      });

    function startRecording() {
      recordedChunks = [];
      mediaRecorder.start();
      alert("Recording started...");
    }

    function stopRecording() {
      mediaRecorder.stop();
      alert("Recording stopped. You can now send the video.");
    }

    videoForm.addEventListener("submit", function(e) {
      e.preventDefault();
      emailjs.sendForm('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', this)
        .then(() => alert("Video sent! 🎉"))
        .catch(err => alert("Failed to send video: " + JSON.stringify(err)));
    });
  </script>
</body>
</html>
```

---

### 3️⃣ Update Your EmailJS Template

In your template's message body, add:

```html
<p>Attached Video:</p>
<video controls src="{{video_data}}" width="320"></video>
```

---

### 4️⃣ Replace Placeholders in Code

| Placeholder        | Replace With                   |
| ------------------ | ------------------------------ |
| `YOUR_PUBLIC_KEY`  | From EmailJS Dashboard         |
| `YOUR_SERVICE_ID`  | From EmailJS email service     |
| `YOUR_TEMPLATE_ID` | From EmailJS template settings |

---

### ✅ 5️⃣ Run It

* Open `index.html` in your browser
* Allow webcam/mic permissions
* Click **Start Recording**
* Click **Stop & Send**
* Enter email → click **Send Video**
* Check the recipient inbox 🎉

---

✅ **Task Complete!**
