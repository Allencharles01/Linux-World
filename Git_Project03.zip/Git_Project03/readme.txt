Task 3 – Fork, Clone, Contribute via Pull Request

🎯 **Goal:** Contribute to open source using GitHub's forking workflow.

---

### 🧰 Requirements

| Item                   | Description                                                                                                         |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------- |
| GitHub Account         | ✅ Logged in                                                                                                         |
| Git installed          | ✅                                                                                                                   |
| VS Code / Terminal     | ✅                                                                                                                   |
| Any public GitHub repo | You can use: [`https://github.com/octocat/Spoon-Knife`](https://github.com/octocat/Spoon-Knife) (safe to test with) |

---

## 🧪 Step-by-Step Instructions

---

### 🍴 Step 1: Fork a Repository

1. Go to: [https://github.com/octocat/Spoon-Knife](https://github.com/octocat/Spoon-Knife)
2. Click **“Fork”** (top right)
3. GitHub will create a copy of that repo under your username

---

### 💻 Step 2: Clone Your Fork Locally

**Where:** VS Code Terminal or CMD
(Replace `your-username` with yours)

```bash
git clone https://github.com/your-username/Spoon-Knife.git
cd Spoon-Knife
```

---

### ✏️ Step 3: Make a Change

Edit or create a file, e.g.:

```bash
echo "Contributing to open source is awesome!" >> contribution.txt
```

---

### ✅ Step 4: Commit Your Changes

```bash
git add .
git commit -m "Add contribution.txt with a test message"
```

---

### ☁️ Step 5: Push to Your Fork on GitHub

```bash
git push origin main
```

> If the repo uses `master` instead of `main`, just replace it accordingly.

---

### 🔃 Step 6: Create a Pull Request

1. Go to your fork: `https://github.com/your-username/Spoon-Knife`
2. Click **“Compare & pull request”**
3. Add a message and click **“Create pull request”**

---

## ✅ Task Complete!
