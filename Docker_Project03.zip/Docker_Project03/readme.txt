**🧠 Project Name:** Run Apache Web Server Inside a Docker Container
**🗂️ Files:** *(Dockerfile and index.html optional for customization)*
**📄 Description:**
This project demonstrates how to deploy an **Apache HTTP web server** using Docker. The container runs a live web server accessible from your local browser via `localhost`.

---

### 🛠️ Features:

* Uses official Apache Docker image (`httpd`)
* Exposes port `80` from the container to host port `8080`
* Optionally supports custom HTML files
* Perfect for static website demos, testing, and learning Docker basics

---

### 🚀 How to Use:

#### ✅ Option A: Run Apache with Default Page

1. Open a terminal and run:

   ```bash
   docker run -dit --name apache-server -p 8080:80 httpd
   ```

2. Visit in browser:

   ```
   http://localhost:8080
   ```

---

#### ✅ Option B (Optional): Add a Custom `index.html`

1. Create a file named `Dockerfile`:

   ```Dockerfile
   FROM httpd:latest
   COPY ./index.html /usr/local/apache2/htdocs/
   ```

2. Create a simple `index.html` in the same folder:

   ```html
   <h1>Hello from Apache in Docker 🚀</h1>
   ```

3. Build and run:

   ```bash
   docker build -t apache-docker .
   docker run -dit --name apache-server -p 8080:80 apache-docker
   ```

4. Visit:

   ```
   http://localhost:8080
   ```

---

### 📌 Notes:

* To stop:

  ```bash
  docker stop apache-server
  ```
* To start:

  ```bash
  docker start apache-server
  ```
* To remove:

  ```bash
  docker rm -f apache-server
  ```

---

### 👨‍💻 Author:

Created by **Allen Charles**
GitHub: [https://github.com/Allencharles01](https://github.com/Allencharles01)