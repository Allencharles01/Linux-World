Project: Send WhatsApp Message using Python + pywhatkit

This Python script uses the `pywhatkit` library to send a scheduled WhatsApp message via WhatsApp Web.
It’s a simple and fun way to automate personal messages without needing any API keys or business accounts.


-> Features

* Send WhatsApp messages using Python
* Uses WhatsApp Web (no third-party API needed)
* Quick setup with just one external library
* Works with personal WhatsApp accounts
* Great for small-scale or personal automation


-> How to Use

1. *Clone this repository*

   git clone [https://github.com/your-username/python-whatsapp-sender.git](https://github.com/your-username/python-whatsapp-sender.git)
   cd python-whatsapp-sender

2. *Install Python (if not installed)*

   Download and install Python from: [https://www.python.org/downloads/](https://www.python.org/downloads/)

3. *Install the required library*

   pip install pywhatkit

4. *Open lw\_project08.py and update the message details*

   Replace:

   * `"+918125229368"` with the recipient’s WhatsApp number (including country code)
   * `"Hello from Python!"` with your desired message
   * `12, 23` with the hour and minute to send the message (in 24-hour format)



-> How It Works

* This script opens **WhatsApp Web** in your browser
* It waits until the scheduled time
* It automatically types and sends the message
* You **must be logged into WhatsApp Web** for this to work



-> Limitations

* Requires a browser to open WhatsApp Web
* Needs an active internet connection and your **login session to be valid**
* Can only **schedule messages by time**, not send instantly
* Not ideal for production or large-scale automation
* Won’t work in **headless or cloud environments**



=> Output Example

When run, you'll see:

```
INFO: Successfully Sent!
```

Browser opens, logs into WhatsApp Web, and sends your message.



Author:
Made by @Allencharles01
GitHub: https://github.com/Allencharles01