PROJECT: Gesture FX Panel using Streamlit + MediaPipe + OpenCV

---

## 🎯 Objective

Create a fun and interactive Streamlit web app that responds to your hand gestures in real-time using your webcam.

Each gesture triggers a unique visual or UI effect in the app, powered by Streamlit.

---

## ⚙️ Features

| Gesture        | Effect Triggered          |
|----------------|---------------------------|
| 👍 Thumbs Up    | 🎈 Balloons in Streamlit    |
| ✌ Peace Sign   | ❄️ Snowfall in Streamlit     |
| ✊ Fist         | 🌙 Switch to Dark Theme      |
| 🖐 Open Palm    | ☀️ Switch back to Light Theme|

---

## 🧱 Tech Stack

- **Streamlit**: For UI and app effects
- **OpenCV**: Webcam and frame rendering
- **MediaPipe**: Real-time hand gesture detection
- **Python**: Backend logic

---

## 🗂 Folder Structure

Gesture_FX_Project/
├── gesture_fx_app.py  
├── requirements.txt  
└── readme.txt

---

## 📦 Installation Steps

1. 🔁 Clone the repository or copy the folder

2. 📦 Install dependencies:

```bash
pip install -r requirements.txt
````

---

## 🚀 Run the App

```bash
streamlit run gesture_fx_app.py
```

> Make sure your webcam is connected.

---

## 🧪 Usage Instructions

1. Run the app.
2. Check the ✅ "Start Webcam" checkbox.
3. Show hand gestures to the webcam.
4. Enjoy interactive FX based on your gestures!

---

## 🧠 Tips

* If camera fails, try changing `cv2.VideoCapture(1)` to `cv2.VideoCapture(0)`
* Ensure sufficient lighting for accurate gesture detection
* Extend with more gestures for fun automations!

---

## Tools Used:

* [MediaPipe Hands](https://google.github.io/mediapipe/solutions/hands)
* [Streamlit](https://streamlit.io/)
* [OpenCV](https://opencv.org/)

