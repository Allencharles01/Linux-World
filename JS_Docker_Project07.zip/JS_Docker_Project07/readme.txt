Task 7: Run Linear Regression Model inside Docker

---

### 🎯 Goal

Use Python to train and execute a simple **Linear Regression** model, all within a **Docker container**.

---

### 📁 Project Structure

This folder should contain the following files:

```

JS\_Docker\_Project07/
├── app.py
├── requirements.txt
├── Dockerfile
├── readme.txt  ← (this file)

````

---

### 🐍 app.py

Python script that:

- Trains a model using `scikit-learn`
- Makes a prediction for input `6`

```python
from sklearn.linear_model import LinearRegression
import numpy as np

# Sample training data
X = np.array([[1], [2], [3], [4], [5]])
y = np.array([3, 6, 9, 12, 15])

model = LinearRegression()
model.fit(X, y)

prediction = model.predict([[6]])
print(f"Prediction for 6: {prediction[0]}")
````

---

### 📦 requirements.txt

List of Python dependencies:

```
scikit-learn
numpy
```

---

### 🐳 Dockerfile

Docker instructions to install dependencies and run the model:

```dockerfile
FROM python:3.10-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY app.py .

CMD ["python", "app.py"]
```

---

### 🚀 How to Build and Run

#### 🛠️ Step 1: Build the Docker image

Open terminal in the `JS_Docker_Project07` folder:

```bash
docker build -t linear-regression-js07 .
```

---

#### ▶️ Step 2: Run the Docker container

```bash
docker run --rm linear-regression-js07
```

---

### ✅ Output

```
Prediction for 6: 18.0
```

---

### 🧠 Extra

To rebuild the image after edits:

```bash
docker build -t linear-regression-js07 .
```

---

✅ **Done!** You’ve now containerized a machine learning model with Docker and Python.
