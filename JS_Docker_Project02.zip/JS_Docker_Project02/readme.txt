Task 2: Send Email Using JavaScript (via EmailJS)

---

### 🎯 **Goal**

Create a contact form that allows users to send emails **directly from the frontend**, using **EmailJS** — no backend or server required.

---

### 🧱 **Tech Stack**

| Tool                           | Purpose                |
| ------------------------------ | ---------------------- |
| HTML + JS                      | Build form & logic     |
| [EmailJS](https://emailjs.com) | Email delivery service |
| Browser                        | To run/test the app    |

---

### ✅ **Steps to Complete**

---

### 1️⃣ Create an EmailJS Account

* Go to: [https://www.emailjs.com](https://www.emailjs.com)
* Create a free account
* Link an email service (like Gmail)
* Create a new **email template**
* Get the following credentials from the dashboard:

  * **Service ID**
  * **Template ID**
  * **Public Key**

---

### 2️⃣ Create a File Named `index.html`

Paste this code inside:

```html
<!DOCTYPE html>
<html>
<head>
  <title>Send Email with EmailJS</title>
  <script src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
</head>
<body>
  <h2>📧 Contact Form</h2>
  <form id="contact-form">
    <input type="text" name="user_name" placeholder="Your Name" required /><br />
    <input type="email" name="user_email" placeholder="Your Email" required /><br />
    <textarea name="message" placeholder="Your Message" required></textarea><br />
    <button type="submit">Send Email</button>
  </form>

  <script>
    (function() {
      emailjs.init("YOUR_PUBLIC_KEY");
    })();

    document.getElementById('contact-form').addEventListener('submit', function(e) {
      e.preventDefault();
      emailjs.sendForm('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', this)
        .then(() => {
          alert('Email sent successfully!');
        }, (err) => {
          alert('Failed to send email:\n' + JSON.stringify(err));
        });
    });
  </script>
</body>
</html>
```

---

### 3️⃣ Replace the Placeholder Values

| Placeholder        | Replace With                        |
| ------------------ | ----------------------------------- |
| `YOUR_PUBLIC_KEY`  | From EmailJS dashboard              |
| `YOUR_SERVICE_ID`  | Your connected service (like Gmail) |
| `YOUR_TEMPLATE_ID` | From your email template            |

---

### ✅ 4️⃣ Run It

* Open `index.html` in your browser
* Fill the form
* Click **Send Email**
* A success or error message will pop up

---

Done!