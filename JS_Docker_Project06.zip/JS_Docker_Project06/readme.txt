Task 6: Fetch Last Email Info Using Gmail API + JavaScript

---

### 🎯 **Goal**

Use Google OAuth 2.0 to authenticate a user, then connect to the Gmail API and fetch:

* ✅ Subject
* ✅ Sender
* ✅ Snippet of the **most recent email**

---

### 🧱 **Tools Used**

| Tool                 | Purpose                   |
| -------------------- | ------------------------- |
| Gmail API            | Access Gmail inbox data   |
| Google OAuth 2.0     | Secure login              |
| HTML + JavaScript    | UI and Gmail API logic    |
| Google Cloud Console | Enable and configure APIs |

---

### 🧪 **Steps to Complete the Task**

---

### 1️⃣ Enable Gmail API and Set Up OAuth

1. Visit: [https://console.cloud.google.com](https://console.cloud.google.com)
2. Create or select a project
3. Go to **APIs & Services > Library**
4. Search for **Gmail API** → Click **Enable**
5. Go to **OAuth consent screen**

   * Choose **External**
   * Fill in app name and your email
   * Add test users (your own Gmail address)
6. Go to **Credentials > Create Credentials > OAuth Client ID**

   * Type: **Web Application**
   * Add `http://localhost` to **Authorized JavaScript origins**
   * Copy your **Client ID**

---

### 2️⃣ Create a File Named `index.html`

Paste this:

```html
<!DOCTYPE html>
<html>
<head>
  <title>Gmail API - Last Email</title>
  <script src="https://apis.google.com/js/api.js"></script>
</head>
<body>
  <h2>📧 Last Email Info</h2>
  <button onclick="handleAuthClick()">Sign in with Google</button>
  <div id="output"></div>

  <script>
    const CLIENT_ID = 'YOUR_CLIENT_ID_HERE';
    const SCOPES = 'https://www.googleapis.com/auth/gmail.readonly';

    function handleClientLoad() {
      gapi.load('client:auth2', initClient);
    }

    function initClient() {
      gapi.client.init({
        clientId: CLIENT_ID,
        scope: SCOPES,
      });
    }

    function handleAuthClick() {
      gapi.auth2.getAuthInstance().signIn().then(() => {
        listEmails();
      });
    }

    function listEmails() {
      gapi.client.load('gmail', 'v1', () => {
        gapi.client.gmail.users.messages.list({
          userId: 'me',
          maxResults: 1,
        }).then(response => {
          const messageId = response.result.messages[0].id;
          gapi.client.gmail.users.messages.get({
            userId: 'me',
            id: messageId,
          }).then(message => {
            const headers = message.result.payload.headers;
            const subject = headers.find(h => h.name === 'Subject')?.value;
            const from = headers.find(h => h.name === 'From')?.value;
            const snippet = message.result.snippet;

            document.getElementById('output').innerHTML =
              `<b>From:</b> ${from}<br><b>Subject:</b> ${subject}<br><b>Snippet:</b> ${snippet}`;
          });
        });
      });
    }

    handleClientLoad();
  </script>
</body>
</html>
```

---

### 3️⃣ Replace in Code:

| Placeholder           | Replace With                                        |
| --------------------- | --------------------------------------------------- |
| `YOUR_CLIENT_ID_HERE` | Your real OAuth Client ID from Google Cloud Console |

---

### 4️⃣ Run the File

> ⚠️ Run it from `http://localhost`
> Use one of these:

* Live Server in VS Code
* Python: `python -m http.server`
* Node: `http-server`

---

### ✅ 5️⃣ Use It

* Open the page in a browser
* Click **"Sign in with Google"**
* Grant permissions
* Your **latest email's subject, sender, and snippet** will be shown

---

✅ **Task Complete!**
You’ve now authenticated with Google and fetched real Gmail data from the browser!