Task 11: Install and Run Firefox Browser Inside Docker (GUI on Windows)

---

## 🎯 Objective

Create a Docker container that installs and launches the **Firefox browser**, and displays it on the **Windows desktop** using **X11 forwarding via VcXsrv**.

---

## 🧰 Requirements

| Tool       | Purpose                             |
|------------|-------------------------------------|
| Docker Desktop (Windows) | To run Linux containers |
| VcXsrv     | X server to display GUI apps        |
| Ubuntu image | Linux base for the container      |
| Firefox    | Installed via APT inside the container |

---

## 📦 Step-by-Step Instructions

---

### 1️⃣ Install & Launch VcXsrv on Windows

- Download: https://sourceforge.net/projects/vcxsrv/
- Run it with:
  - ✅ Multiple windows
  - ✅ Disable access control
  - ✅ Start with defaults
- Keep it running in the background.

---

### 2️⃣ Get Your Local Host IP

Open CMD or PowerShell:

```

ipconfig

````

Look for `IPv4 Address`, e.g. `192.168.0.201`

---

### 3️⃣ Create `Dockerfile`

Save this in your working folder:

```Dockerfile
FROM ubuntu:22.04

ENV DEBIAN_FRONTEND=noninteractive

RUN apt update && \
    apt install -y firefox x11-apps

CMD ["firefox"]
````

---

### 4️⃣ Build Docker Image

In your terminal, run:

```
docker build -t firefox-docker .
```

---

### 5️⃣ Run the Container with GUI Support

Replace the IP with your real one:

```
docker run --rm \
  -e DISPLAY=192.168.0.201:0 \
  -v /tmp/.X11-unix:/tmp/.X11-unix \
  firefox-docker
```

---

## ✅ Output

* Firefox will launch as a **separate window** on your Windows desktop.
* You’re now running a full GUI browser from inside Docker 💥

---

## 🧠 Notes

* Make sure VcXsrv is **running before** starting the container
* You can replace `firefox` in the Dockerfile with any other GUI app (like `xterm`, `gedit`, etc.)

---

## 🏁 Done!